Multilinear dynamical system for tensor time series

1. to run the example on synthetic data
  make demo

2. to run mlds on SST data set
  matlab -r demo_sst.m
