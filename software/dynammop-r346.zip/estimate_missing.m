function [ Y ] = estimate_missing( X, Ez, model, observed )
%ESTIMATE_MISSING Summary of this function goes here
%   estimate the missing values in X
%
% $Author: leili $@cs.cmu.edu
% $Date: 2010-11-17 00:04:12 -0500 (Wed, 17 Nov 2010) $
% $Rev: 295 $
%

N = size(X, 2);
Y = X;
for i = 1 : N
  Y(:, i) = model.C * Ez{i};
end
end

