function [h] = condentropy(a, b)
%CONDENTROPY  Estimates the conditional entropy from confusion matrix
%          H(column | row)
%
% To be used as a metric for clustering, use H( prediction | true labels )
% a = true label, b = prediction
%
% [h] = condentropy(a) computes the conditional entropy using a as
% confusion matrix
%
% [h] = condentropy(a, b) first computes the confusion matrix from two vectors
% a, b, and then computes the conditional entropy 
%   
% $Author: leili $@cs.cmu.edu
% $Date: 2011-10-12 21:29:51 -0400 (Wed, 12 Oct 2011) $
% $Rev: 339 $

if (nargin > 1)
  cmat = confusionmat(a, b);
else
  cmat = a;
end
s = sum(cmat, 2);
total = sum(s);
s(s==0) = 1;
if (total == 0) total = 1; end
condp = cmat ./ repmat(s, 1, size(cmat, 2));
condp(cmat == 0) = 1;
jointp = cmat / total;
h = - sum(sum(jointp .* log(condp)));