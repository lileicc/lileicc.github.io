How to quick run:
try 
make demo


about the clustering:
1. labels
2=walking
3=running

2. simply try to run test_clds_mocap16.m in matlab (2010a or above)

CopyRight (c) Lei Li(leili@cs.cmu.edu), 2011
$Revision: 334 $
