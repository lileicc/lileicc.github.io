/* This source code is (c) Copyright 2008 by Lei Li.
 * All rights preserved.
 *
 * Permission is granted to use it for non-profit purposes,
 * including research and teaching. For-profit use requires
 * the express consent of the author (leili@cs.cmu.edu).
 */

#include "matrix.h"
#include <iostream>
#include <cassert>
#include <math.h>
using namespace std;

Vector * newVector(int n) {
	Vector * vec = new Vector;
	vec->n = n;
	vec->data = new double[n];
	return vec;
}

Matrix * newMatrix(int n, int m) {
	Matrix * mat = new Matrix;
	mat->n = n;
	mat->m = m;
	mat->data = new double[n * m];
	return mat;
}

void zeros(Vector * a) {
	memset(a->data, 0, sizeof(double) * (a->n));
}

void zeros(Matrix * A) {
	memset(A->data, 0, sizeof(double) * (A->n) * (A->m));
}

void eye(Matrix * A) {
	int i;
	memset(A->data, 0, sizeof(double) * (A->n) * (A->m));
	for (i=0; (i < A->n) && (i < A->m); i++) {
		A->data[i * (A->m) + i] = 1;
	}
}

double getValue(Matrix * mat, int i, int j) {
	return mat->data[i * mat->m + j];
}

double getValue(Vector * vec, int i) {
	return vec->data[i];
}

void copy(Matrix * A, Matrix * B) {
	memcpy(B->data, A->data, sizeof(double)*(A->n)*(A->m));
}

void copy(Vector * A, Vector * B) {
	memcpy(B->data, A->data, sizeof(double)*(A->n));
}

Vector * makeVector(double* data, int n)
{
	Vector * vec = new Vector;
	vec->n = n;
	vec->data = new double[n];
	memcpy(vec->data, data, sizeof(double)*n);
	return vec;
}

Matrix * makeMatrix(double* data, int n, int m)
{
	Matrix * mat = new Matrix;
	mat->n = n;
	mat->m = m;
	mat->data = new double[n*m];
	memcpy(mat->data, data, sizeof(double)*n*m);
	return mat;
}

void deleteVector(Vector* vec)
{
	delete [] vec->data;
	delete vec;
}

void deleteMatrix(Matrix* mat)
{
	delete [] mat->data;
	delete mat;
}

double trace(Matrix * mat) {
	int n = mat->n;
	int m = mat->m;
	assert(n==m);	

	double s = 0;
	for (int i = 0; i < n; i++)
	{
		s+=mat->data[i*n+i];
	}
	return s;
}

// B = A + x * y';
void addOuterProd(Matrix * A, Vector * x, Vector * y, Matrix* B) {
    int i, j, m;
    m = A->m;
    for (i = 0; i < x->n; i++) {
        for (j=0; j < y->n; j++) {
            B->data[i*m+j] = A->data[i*m+j] + x->data[i] * y->data[j];
        }
    }
}

// c = alpha * a;
void scale(Vector * a, double alpha, Vector * c)
{
	int n = a->n;
	c->n = n;
	for (int i = 0; i < n; i++)
		c->data[i] = a->data[i] * alpha;
}

// C = alpha * A
void scale(Matrix * A, double alpha, Matrix * C)
{
	int n = A->n;
	int m = A->m;
	C->n = n;
	C->m = m;
	for (int i = 0; i < n*m; i++)
		C->data[i] = A->data[i] * alpha;
}

//sum of the abs of x
double sumAbs(Vector *x) {
	double s = 0;
	for (int i = 0; i < x->n; i++)
	{
		s+=fabs(x->data[i]);
	}
	return s;
}


// C = diag(A)
void diag(Matrix * A, Matrix * C) {
	int n = A->n;
	int m = A->m;
	assert(n==m);	
	for (int i = 0; i < (n-1); i++) {
		memset((C->data)+i*n+i+1, 0, sizeof(double)*n);
	}
	if (A != C) {
		for (int i = 0; i < n; i++) {
			C->data[i*n+i] = A->data[i*n+i];
		}		
	}
}


// C = only keep diagonal of value
void diag(double value, Matrix * C) {
	int n = C->n;
	int m = C->m;
	assert(n==m);	
	memset((C->data), 0, sizeof(double)*n*n);
	for (int i = 0; i < n; i++) {
		C->data[i*n+i] = value;
	}
}


// c(i) = a(i) + b(i)
void add(Vector * a, Vector * b, Vector * c)
{
	c->n = a->n;
	for (int i = 0; i < a->n; i++)
		c->data[i] = a->data[i]+b->data[i];
}

// c(i,j) = a(i,j) + b(i,j)
void add(Matrix * a, Matrix * b, Matrix * c)
{
	c->n = a->n;
	c->m = a->m;
	for (int i = 0; i < a->n*a->m; i++)
		c->data[i] = a->data[i]+b->data[i];
}

// c(i) = a(i) - b(i)
void substract(Vector * a, Vector * b, Vector * c)
{
	c->n = a->n;
	for (int i = 0; i < a->n; i++)
		c->data[i] = a->data[i]-b->data[i];
}

// c(i,j) = a(i,j) - b(i,j)
void substract(Matrix * a, Matrix * b, Matrix * c)
{
	c->n = a->n;
	c->m = a->m;
	for (int i = 0; i < a->n*a->m; i++)
		c->data[i] = a->data[i]-b->data[i];
}

/* if (opA == 0)
 * 		y = A * x
 * elseif (opA == 1)
 * 		y = A' * x;
 * else
 * 		error!
 * end
 * 
 */ 
void multiply(Matrix * A, int opA, Vector * x, Vector * y)
{
	int n = A->n, m = A->m;
	if (opA == 0)
	{
		y->n = n;
		memset(y->data, 0, sizeof(double)*n);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
				y->data[i] += A->data[i*m+j] * x->data[j];
	}
	else
	{
		y->n = m;
		memset(y->data, 0, sizeof(double)*m);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
				y->data[j] += A->data[i*m+j] * x->data[i];
	}
}

/* if (opA == 0 && opB == 0)
 * 		C = A * B
 * elseif (opA == 1 && opB == 0)
 * 		C = A' * B;
 * elseif (opA == 0 && opB == 1)
 * 		C = A * B';
 * elseif (opA == 1 && opB == 1)
 * 		C = A' * B';
 * else
 * 		error!
 * end
 * 
 */
void multiply(Matrix * A, int opA, Matrix * B, int opB, Matrix * C)
{
	if (opA == 0)
	{
		if (opB == 0)
		{
			int s1 = A->n, s2 = A->m, s3 = B->m;
			C->n = s1;
			C->m = s3;
			memset(C->data, 0, sizeof(double)*s1*s3);
			for (int i = 0; i < s1; i++)
				for (int j = 0; j < s2; j++)
					for (int k = 0; k < s3; k++)
						C->data[i*s3+k] += A->data[i*s2+j] * B->data[j*s3+k];
		}
		else
		{
			int s1 = A->n, s2 = A->m, s3 = B->n;
			C->n = s1;
			C->m = s3;
			memset(C->data, 0, sizeof(double)*s1*s3);
			for (int i = 0; i < s1; i++)
				for (int k = 0; k < s3; k++)
					for (int j = 0; j < s2; j++)
						C->data[i*s3+k] += A->data[i*s2+j] * B->data[k*s2+j];
		}
	}
	else
	{
		if (opB == 0)
		{
			int s1 = A->m, s2 = A->n, s3 = B->m;
			C->n = s1;
			C->m = s3;
			memset(C->data, 0, sizeof(double)*s1*s3);
			for (int j = 0; j < s2; j++)
				for (int i = 0; i < s1; i++)
					for (int k = 0; k < s3; k++)
						C->data[i*s3+k] += A->data[j*s1+i] * B->data[j*s3+k];
		}
		else
		{
			int s1 = A->m, s2 = A->n, s3 = B->n;
			C->n = s1;
			C->m = s3;
			memset(C->data, 0, sizeof(double)*s1*s3);
			for (int k = 0; k < s3; k++)
				for (int j = 0; j < s2; j++)
					for (int i = 0; i < s1; i++)
						C->data[i*s3+k] += A->data[j*s1+i] * B->data[k*s2+j];
		}
	}
}

/*
 * if opB == 0
 * to solve X * A = B, X = B * A^{-1}
 * elseif opB = 1
 * to solve X * A = B', X = B' * A^{-1}
 * where A is symmetrix
 */ 
void symSolveRinv(Matrix * A, Matrix * B, int opB, Matrix * X)
{
	int m = A->m;
	Matrix * C = newMatrix(m, m);
	memcpy(C->data, A->data, sizeof(double)*m*m);
	Matrix * D = newMatrix(m, m);
	memset(D->data, 0, sizeof(double)*m*m);
	for (int i = 0; i < m; i++)
		D->data[i*m+i] = 1;
	for (int i = 0; i < m; i++)
	{
		double d1 = C->data[i*m+i];
		assert(d1 > 0);
		for (int k = i; k < m; k++)
			C->data[i*m+k] /= d1;
		for (int k = 0; k < m; k++)
			D->data[i*m+k] /= d1;
		for (int j = i+1; j < m; j++)
		{
			double d = - C->data[j*m+i];
			C->data[j*m+i] = 0;
			for (int k = i+1; k < m; k++)
				C->data[j*m+k] += d * C->data[i*m+k];
			for (int k = 0; k < m; k++)
				D->data[j*m+k] += d * D->data[i*m+k];
		}
	}
	for (int i = m-1; i >= 0; i--)
		for (int j = i+1; j < m; j++)
		{
			double d = - C->data[i*m+j];
			//for (k = j+1; k < m; k++)
			//	C->data[i*m+k] += d * C->data[j*m+k];
			for (int k = 0; k < m; k++)
				D->data[i*m+k] += d * D->data[j*m+k];

		}
	multiply(B, opB, D, 0, X);
	deleteMatrix(C);
	deleteMatrix(D);
}

void outputVector(Vector * vec)
{
	cout << '[';
	for (int i = 0; i < vec->n; i++) cout << vec->data[i] << ' ';
	cout << "];" << endl;
}

void outputMatrix(Matrix * mat)
{
	cout << '[';
	for (int i = 0; i < mat->n; i++)
	{
		for (int j = 0; j < mat->m; j++)
			cout << mat->data[i*mat->m+j] << ' ';
		if (i < mat->n - 1) cout << ';';
	}
	cout << "];" << endl;
}
/*
void main()
{
	int n = 5;
	Matrix * m1 = newMatrix(n, n);
	Matrix * m2 = newMatrix(n, n);
	Matrix * m3 = newMatrix(n, n);
	Vector * v1 = newVector(n);
	Vector * v2 = newVector(n);
	randFill(n*n, m1->data);
	randFill(n*n, m2->data);
	randFill(n*n, m3->data);
	randFill(n, v1->data);
	randFill(n, v2->data);

	cout << "m1="; outputMatrix(m1);
	cout << "m2="; outputMatrix(m2);
	cout << "m3="; outputMatrix(m3);
	cout << "v1="; outputVector(v1);
	cout << "v2="; outputVector(v2);

	Vector * rv = newVector(n);
	Matrix * rm = newMatrix(n,n);
	scale(v1, 10, rv);
	outputVector(rv);
	add(v1, v2, rv);
	outputVector(rv);
	substract(v1, v2, rv);
	outputVector(rv);
	scale(m1, 10, rm);
	outputMatrix(rm);
	add(m1, m2, rm);
	outputMatrix(rm);
	substract(m1, m2, rm);
	outputMatrix(rm);

	multiply(m1, 0, v1, rv);
	outputVector(rv);
	multiply(m1, 1, v1, rv);
	outputVector(rv);

	multiply(m1, 0, m2, 0, rm);
	outputMatrix(rm);
	multiply(m3, 0, m2, 1, rm);
	outputMatrix(rm);
	multiply(m3, 1, m2, 0, rm);
	outputMatrix(rm);
	multiply(m1, 1, m3, 1, rm);
	outputMatrix(rm);

	Matrix * p = newMatrix(n,n);
	multiply(m3, 0, m3, 1, p);

	Matrix * mI = newMatrix(n, n);
	memset(mI->data, 0, sizeof(double)*n*n);
	for (int i = 0; i < n; i++) mI->data[i*n+i] = 1;

	symSolveRinv(p, m1, 0, rm);
	outputMatrix(rm);
	symSolveRinv(p, m2, 1, rm);
	outputMatrix(rm);

	symSolveRinv(p, mI, 0, rm);
	outputMatrix(rm);

}
*/
