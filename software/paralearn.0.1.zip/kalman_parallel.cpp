/* This source code is (c) Copyright 2008 by Lei Li.
 * All rights preserved.
 *
 * Permission is granted to use it for non-profit purposes,
 * including research and teaching. For-profit use requires
 * the express consent of the author (leili@cs.cmu.edu).
 */

#include <iostream>
#include <fstream>
#include <math.h>
#include <omp.h>
#include <sys/time.h>
#include "matrix.h"

#define MAX_ITER 1000

#define MAXPROC 513 

using namespace std;

typedef struct {
	Matrix* A;
	Matrix* C;
	Matrix* Gamma;
	Matrix* Sigma;
	Vector* u0;
	Matrix* V0;
	int M;
	int H;
} KalmanModel;

typedef struct {
	Vector** mu;
	Matrix** V;
	Matrix** P;
	Matrix** J;
	Vector** muhat;
	Matrix** Vhat;
	int N;
} KalmanMessage;

typedef struct {
	Vector ** x;
	int N;
	int M;
	int H;
} KalmanData;

struct timeval startInitTime, startCompTime, endCompTime, endTotalTime;

/*
used for tracking the convergence
*/
double LL[MAX_ITER];

KalmanModel * initModel(int m, int h) {
	KalmanModel * model = new KalmanModel;
	model->M = m;
	model->H = h;
	model->A = newMatrix(h, h);
	model->C = newMatrix(m, h);
	model->Gamma = newMatrix(h, h);
	model->Sigma = newMatrix(m, m);
	model->u0 = newVector(h);
	model->V0 = newMatrix(h, h);
	eye(model->A);
	eye(model->C);
	eye(model->Gamma);
	eye(model->Sigma);
	eye(model->V0);
	return model;
}

void deleteModel(KalmanModel * model) {
	deleteMatrix(model->A);
	deleteMatrix(model->C);
	deleteMatrix(model->Gamma);
	deleteMatrix(model->Sigma);
	deleteVector(model->u0);
	deleteMatrix(model->V0);
	delete model;
}

KalmanMessage * initMess(int n, int m, int h) {
	int i;
	KalmanMessage * mess = new KalmanMessage;
	mess->J = new Matrix*[n];
	mess->P = new Matrix*[n];
	mess->V = new Matrix*[n];
	mess->Vhat = new Matrix*[n];
	mess->mu = new Vector*[n];
	mess->muhat = new Vector*[n];
	mess->N = n;
	for (i = 0; i < n; i++) {
		mess->J[i] = newMatrix(h,h);
		mess->P[i] = newMatrix(h,h);
		mess->V[i] = newMatrix(h,h);
		mess->Vhat[i] = newMatrix(h,h);
		mess->mu[i] = newVector(h);
		mess->muhat[i] = newVector(h);
	}
	return mess;
}

void deleteMess(KalmanMessage * mess) {
	int i;     
	for (i = 0; i < mess->N; i++) {
		deleteMatrix(mess->J[i]);
		deleteMatrix(mess->P[i]);
		deleteMatrix(mess->V[i]);
		deleteMatrix(mess->Vhat[i]);
		deleteVector(mess->mu[i]);
		deleteVector(mess->muhat[i]);
	}
	delete [] mess->J;
	delete [] mess->P;
	delete [] mess->V;
	delete [] mess->Vhat;
	delete [] mess->mu;
	delete [] mess->muhat;
	delete mess;
}


void learning(KalmanData * data, KalmanModel * model, int numProcs) {
	int n, m, h;
	int procNSize;
	int rem;
	
	KalmanMessage * mess;
	
	//temporary matrix
	Matrix ** tmpKC = new Matrix*[numProcs];
	Matrix ** tmphm = new Matrix*[numProcs];
	Matrix ** tmphh = new Matrix*[numProcs];
	Matrix ** tmpmh = new Matrix*[numProcs];
	Vector ** tmph = new Vector*[numProcs];
	Vector ** delta = new Vector*[numProcs];
	Matrix ** delV = new Matrix*[numProcs];
	
	//use for statistics
	Matrix ** sumhh1 = new Matrix*[numProcs];
	Matrix ** sumhh = new Matrix*[numProcs];
	Matrix ** summh = new Matrix*[numProcs];

	//block V0 and block Vhat_n
	Matrix ** V0_block = new Matrix*[numProcs];
	Matrix ** Vhat_block = new Matrix*[numProcs];
	Vector ** u0_block = new Vector*[numProcs];
	Vector ** uhat_block = new Vector*[numProcs];

	Matrix * sumN;
	Matrix * covx;
	
	//other message
	Matrix ** K = new Matrix*[numProcs];
	Vector ** u_c = new Vector*[numProcs];
	Matrix ** sigma_c = new Matrix*[numProcs];

	//used for convergence test;
	double * tmpLL = new double[numProcs];
	memset(tmpLL, 0, sizeof(double) * numProcs);
	
	//initialize
	n = data->N;
	m = data->M;
	h = model->H;
	procNSize = n / numProcs; 
	rem = n - procNSize * numProcs;


    covx = newMatrix(m,m);
    zeros(covx);
    for (int i=0; i<n; i++) {
		addOuterProd(covx, data->x[i], data->x[i], covx);
    }

	//message variables
	mess = initMess(n,m,h);

	sumN = newMatrix(h, h);
	
#pragma omp parallel default(shared)
    {
        
        /* Obtain and print thread id */
        int tid = omp_get_thread_num();
        
		K[tid] = newMatrix(h, m);
     	u_c[tid] = newVector(m);
      	sigma_c[tid] = newMatrix(m, m);
      	
      	
      	tmphm[tid] = newMatrix(h, m);
       	tmpmh[tid] = newMatrix(m, h);
        tmphh[tid] = newMatrix(h, h);
        tmph[tid] = newVector(h);
        delta[tid] = newVector(m);
       	tmpKC[tid] = newMatrix(h, h);
        delV[tid] = newMatrix(h, h);
        
        sumhh[tid] = newMatrix(h, h);
        summh[tid] = newMatrix(m, h);
        sumhh1[tid] = newMatrix(h, h);
        
		if (tid==0)
		{
			u0_block[tid] = model->u0;
			V0_block[tid] = model->V0;
		} else {
			u0_block[tid] = newVector(h);
			V0_block[tid] = newMatrix(h, h);
		}
		if (tid < numProcs - 1)
		{
			Vhat_block[tid] = newMatrix(h, h);
			uhat_block[tid] = newVector(h);
		}    
    }
        
#pragma omp parallel default(shared) 
{

    /* Record start computation time. */
  if (omp_get_thread_num() == 0) {
	  gettimeofday(&startCompTime, NULL);
	int tid = 0;

		for (int i = 0; i < n; i++) {
            /* Obtain and print thread id */
            
			if (i==0) {
				copy(model->V0, mess->P[0]);
				copy(model->u0, mess->mu[0]);
			} else {
				multiply(model->A, 0, mess->V[i-1], 0, tmphh[tid]);
				multiply(tmphh[tid], 0, model->A, 1, mess->P[i]);
				add(mess->P[i], model->Gamma, mess->P[i]);
				
				multiply(model->A, 0, mess->mu[i-1], mess->mu[i]);
			}
			
			multiply(model->C, 0, mess->mu[i], u_c[tid]);
			
			multiply(mess->P[i], 0, model->C, 1, tmphm[tid]);
			multiply(model->C, 0, tmphm[tid], 0, sigma_c[tid]);
			add(sigma_c[tid], model->Sigma, sigma_c[tid]);
			symSolveRinv(sigma_c[tid], tmphm[tid], 0, K[tid]);
			
			substract(data->x[i], u_c[tid], delta[tid]);
			multiply(K[tid], 0, delta[tid], tmph[tid]);
			add(mess->mu[i], tmph[tid], mess->mu[i]);
			multiply(K[tid], 0, model->C, 0, tmpKC[tid]);
			multiply(tmpKC[tid], 0, mess->P[i], 0, tmphh[tid]);
			substract(mess->P[i], tmphh[tid], mess->V[i]);
		}

		//backward
		for (int i = n-1; i>=0; i--) {
            /* Obtain and print thread id */
                        
            if (i==n-1) {
               copy(mess->mu[n-1], mess->muhat[n-1]);
               copy(mess->V[n-1], mess->Vhat[n-1]);
            } else {
	           multiply(mess->V[i], 0, model->A, 1, tmphh[tid]);
           	   symSolveRinv(mess->P[i+1], tmphh[tid], 0, mess->J[i]);
	           multiply(model->A, 0, mess->mu[i], tmph[tid]);
               substract(mess->muhat[i+1], tmph[tid], tmph[tid]);
	           multiply(mess->J[i], 0, tmph[tid], mess->muhat[i]);
	           add(mess->mu[i], mess->muhat[i], mess->muhat[i]);
	           substract(mess->Vhat[i+1], mess->P[i+1], delV[tid]);
	           multiply(mess->J[i], 0, delV[tid], 0, tmphh[tid]);
	           multiply(tmphh[tid], 0, mess->J[i], 1, mess->Vhat[i]);
	           add(mess->V[i], mess->Vhat[i], mess->Vhat[i]);
            }

			//compute difference
		   multiply(model->C, 0, mess->muhat[i], delta[tid]);
		   substract(delta[tid], data->x[i], delta[tid]);
		   tmpLL[tid] += sumAbs(delta[tid]);
	    }



  }

#pragma omp barrier
    ;


	int tid = omp_get_thread_num();
	int head;
	int tail;
	if (tid < rem)
	{
		head = tid * (procNSize + 1);
		tail = (tid+1) * (procNSize + 1) - 1;
	} else {
		head = tid * procNSize + rem;
		tail = (tid+1) * procNSize - 1 + rem;
	}

	for (int iter = 0; iter < MAX_ITER; iter++) {

		/* compute the sufficient statistics */
		/* estimate new parameter */

        {	
          /* Obtain and print thread id */
           tid = omp_get_thread_num();

		//   printf("M step 1 for thread #%d, from %d to %d\n", tid, head, tail);
        
		   zeros(sumhh1[tid]);
   		   for (int i=head; (i<=tail) && (i <(n-1)); i++) {
	            multiply(mess->J[i], 0, mess->Vhat[i+1], 0, tmphh[tid]);
      	        addOuterProd(tmphh[tid], mess->muhat[i+1], mess->muhat[i], tmphh[tid]);
	            add(sumhh1[tid], tmphh[tid], sumhh1[tid]);
           }		   

	//	   printf("M step 2 for thread #%d, from %d to %d\n", tid, head, tail);
	
           zeros(summh[tid]);
       	   zeros(sumhh[tid]);
	       for (int i=head; (i<=tail) && (i<(n-1)); i++) {
               addOuterProd(mess->Vhat[i], mess->muhat[i], mess->muhat[i], tmphh[tid]);
	           add(sumhh[tid], tmphh[tid], sumhh[tid]);
	           addOuterProd(summh[tid], data->x[i], mess->muhat[i], summh[tid]);
           }    
           
			
		
        }
#pragma omp barrier
    ;	  
        

        {	
          /* Obtain and print thread id */
           tid = omp_get_thread_num();
                
	       if (tid == 0) {
              for (int i = 1; i < numProcs; i++) {
                  add(sumhh1[i], sumhh1[0], sumhh1[0]);
              }
           }
           
           if (tid==(1 % numProcs)) {
              for (int i = 1; i < numProcs; i++) {
                  add(sumhh[i], sumhh[0], sumhh[0]);
              }
                       
              addOuterProd(mess->Vhat[n-1], mess->muhat[n-1], mess->muhat[n-1], tmphh[tid]);
	          add(sumhh[0], tmphh[tid], sumN);
	          	   
           }
           
           if (tid == (2 % numProcs)) {
              for (int i = 1; i < numProcs; i++) {
                  add(summh[i], summh[0], summh[0]);
              }                   
              addOuterProd(summh[0], data->x[n-1], mess->muhat[n-1], summh[0]);
           }
           
           
           //update the parameter
           if (tid == (3 % numProcs)) {
	          copy(mess->muhat[0], model->u0);
	          copy(mess->Vhat[0], model->V0);
           }
        }
#pragma omp barrier
    ;	  
	    
        {	
          /* Obtain and print thread id */
           tid = omp_get_thread_num();	    
           
           if (tid == 0) {
              symSolveRinv(sumhh[0], sumhh1[0], 0, model->A);
              
      		  multiply(model->A, 0, sumhh[0], 0, tmphh[tid]);
      		  substract(tmphh[tid], sumhh1[0], tmphh[tid]);
		      multiply(tmphh[tid], 0, model->A, 1, delV[tid]);
		      multiply(model->A, 0, sumhh1[0], 1, tmphh[tid]);
              substract(delV[tid], tmphh[tid], model->Gamma);
		
		      addOuterProd(mess->Vhat[0], mess->muhat[0], mess->muhat[0], tmphh[0]);
		      substract(model->Gamma, tmphh[0], model->Gamma);
		      add(model->Gamma, sumN, model->Gamma);
		      scale(model->Gamma, 1.0 / (n-1), model->Gamma);

			  //make it as diagnol
			  diag(trace(model->Gamma) / h, model->Gamma);
           }
           
           if (tid == (1 % numProcs)) {
              symSolveRinv(sumN, summh[0], 0, model->C);
              
              multiply(model->C, 0, sumN, 0, tmpmh[tid]);
		      substract(tmpmh[tid], summh[0], tmpmh[tid]);
		      multiply(tmpmh[tid], 0, model->C, 1, model->Sigma);
		      multiply(model->C, 0, summh[0], 1, sigma_c[tid]);
		      substract(model->Sigma, sigma_c[tid], model->Sigma);
		      add(model->Sigma, covx, model->Sigma);
	          scale(model->Sigma, 1.0/n, model->Sigma);              

			  //make it as diagnol
			  diag(trace(model->Sigma) / m, model->Sigma);
           }

		   if (tid == (2 % numProcs))
		   {
			   for (int i = 0; i < numProcs; i++)
			   {
					LL[iter] += tmpLL[i];
			   }
		   }

		   tmpLL[tid] = 0;
        }    
#pragma omp barrier
    ;	 


		{
			tid = omp_get_thread_num();	    
			if (tid>0) {
				multiply(model->A, 0, mess->mu[head-1], u0_block[tid]);

				multiply(model->A, 0, mess->V[head-1], 0, tmphh[tid]);
				multiply(tmphh[tid], 0, model->A, 1, V0_block[tid]);
				add(V0_block[tid], model->Gamma, V0_block[tid]);
			}

			if (tail < n - 1)
			{
				copy(mess->muhat[tail+1], uhat_block[tid]);
				copy(mess->Vhat[tail+1], Vhat_block[tid]);
			}
		}
#pragma omp barrier
    ;


		for (int i = head; i <= tail; i++) {
            /* Obtain and print thread id */
            tid = omp_get_thread_num();
            
			if (i==head) {
				//for the block initial, use the block parameters
				copy(V0_block[tid], mess->P[i]);				
				copy(u0_block[tid], mess->mu[i]);
			} else {
				multiply(model->A, 0, mess->V[i-1], 0, tmphh[tid]);
				multiply(tmphh[tid], 0, model->A, 1, mess->P[i]);
				add(mess->P[i], model->Gamma, mess->P[i]);
				
				multiply(model->A, 0, mess->mu[i-1], mess->mu[i]);
			}
			
			multiply(model->C, 0, mess->mu[i], u_c[tid]);
			
			multiply(mess->P[i], 0, model->C, 1, tmphm[tid]);
			multiply(model->C, 0, tmphm[tid], 0, sigma_c[tid]);
			add(sigma_c[tid], model->Sigma, sigma_c[tid]);
			symSolveRinv(sigma_c[tid], tmphm[tid], 0, K[tid]);
			
	//		void substract(Vector * a, Vector * b, Vector * c);
			substract(data->x[i], u_c[tid], delta[tid]);
			multiply(K[tid], 0, delta[tid], tmph[tid]);
			add(mess->mu[i], tmph[tid], mess->mu[i]);
			multiply(K[tid], 0, model->C, 0, tmpKC[tid]);
			multiply(tmpKC[tid], 0, mess->P[i], 0, tmphh[tid]);
			substract(mess->P[i], tmphh[tid], mess->V[i]);
		}
#pragma omp barrier
    ;
		//backward message passing



		for (int i = tail; i>=head; i--) {
            /* Obtain and print thread id */
			if (i==n-1) {
               copy(mess->mu[n-1], mess->muhat[n-1]);
               copy(mess->V[n-1], mess->Vhat[n-1]);
			} else if (i==tail) {
				//use block parameter
	           multiply(mess->V[i], 0, model->A, 1, tmphh[tid]);

           	   symSolveRinv(mess->P[i+1], tmphh[tid], 0, mess->J[i]);
	           multiply(model->A, 0, mess->mu[i], tmph[tid]);
               substract(uhat_block[tid], tmph[tid], tmph[tid]);
	           multiply(mess->J[i], 0, tmph[tid], mess->muhat[i]);
	           add(mess->mu[i], mess->muhat[i], mess->muhat[i]);
	           substract(Vhat_block[tid], mess->P[i+1], delV[tid]);
	           multiply(mess->J[i], 0, delV[tid], 0, tmphh[tid]);
	           multiply(tmphh[tid], 0, mess->J[i], 1, mess->Vhat[i]);
	           add(mess->V[i], mess->Vhat[i], mess->Vhat[i]);
            } else {
	           multiply(mess->V[i], 0, model->A, 1, tmphh[tid]);
           	   symSolveRinv(mess->P[i+1], tmphh[tid], 0, mess->J[i]);
	           multiply(model->A, 0, mess->mu[i], tmph[tid]);
               substract(mess->muhat[i+1], tmph[tid], tmph[tid]);
	           multiply(mess->J[i], 0, tmph[tid], mess->muhat[i]);
	           add(mess->mu[i], mess->muhat[i], mess->muhat[i]);
	           substract(mess->Vhat[i+1], mess->P[i+1], delV[tid]);
	           multiply(mess->J[i], 0, delV[tid], 0, tmphh[tid]);
	           multiply(tmphh[tid], 0, mess->J[i], 1, mess->Vhat[i]);
	           add(mess->V[i], mess->Vhat[i], mess->Vhat[i]);
            }

		   //compute difference
		   multiply(model->C, 0, mess->muhat[i], delta[tid]);
		   substract(delta[tid], data->x[i], delta[tid]);
		   tmpLL[tid] += sumAbs(delta[tid]);
	    }
#pragma omp barrier
    ;

	}


//#pragma omp parallel private(tid)
    {
        /* Obtain and print thread id */
        int tid = omp_get_thread_num();     
		
		            
		if (tid==0)
		{
			/* Record final time. */
			gettimeofday(&endCompTime, NULL);
		}
			
        
        deleteMatrix(tmpKC[tid]);	
        deleteMatrix(tmphm[tid]);
	    deleteMatrix(tmphh[tid]);
	    deleteMatrix(tmpmh[tid]);
	    deleteVector(tmph[tid]);
	    deleteVector(delta[tid]);
	    deleteMatrix(delV[tid]);
    	deleteMatrix(sumhh1[tid]);
	    deleteMatrix(sumhh[tid]);
	    deleteMatrix(summh[tid]);
	    deleteMatrix(K[tid]);
	    deleteVector(u_c[tid]);
	    deleteMatrix(sigma_c[tid]);
		if (tid>0)
		{
			deleteVector(u0_block[tid]); 
			deleteMatrix(V0_block[tid]);
		}
		if (tid < numProcs - 1)
		{
			deleteMatrix(Vhat_block[tid]);
			deleteVector(uhat_block[tid]);
		}
    }
#pragma omp barrier
    ;	  
	//temporary matrix
}
	
	//use for statistics
	deleteMatrix(sumN);
	deleteMatrix(covx);
	
	delete [] tmpKC;
	delete [] tmphm;
	delete [] tmphh;
	delete [] tmpmh;
	delete [] tmph;
	delete [] delta;
	delete [] delV;
	
	//use for statistics
	delete [] sumhh1;
	delete [] sumhh;
	delete [] summh;

	//delete block parameters
	delete [] u0_block;
	delete [] V0_block;
	delete [] uhat_block;
	delete [] Vhat_block;

	delete [] K;
	delete [] u_c;
	delete [] sigma_c;

	delete [] tmpLL;

	//delete message
	deleteMess(mess);
}


KalmanData * readData(char * fname) {
	int i, j, n, m, h;
	KalmanData * data = new KalmanData;
	double * num;
	
	ifstream cin(fname);
	
	cin>> n >> m >> h;
	data = new KalmanData;
	data->N = n;
	data->M = m;
	data->H = h;
	num = new double[m];
	data->x = new Vector*[n];
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			cin >> num[j];
		}
		data->x[i] = makeVector(num, m);
	}
	delete [] num;
	return data;
}

void deleteData(KalmanData * data) {
	for (int i=0; i < data->N; i++)
	{
		deleteVector(data->x[i]);
	}
	delete [] data->x;
	delete data;
}

void outputModel(KalmanModel * model) {
	int i,j;
	
	ofstream cout("output.txt");
	
	cout<<"A : \n";
	for (i = 0; i < model->H; i++) {
		for (j = 0; j < model->H; j++) cout << getValue(model->A, i, j) <<'\t';
		cout << "\n";
	}
	cout << "\n";
	
	cout<<"Gamma : \n";
	for (i = 0; i < model->H; i++) {
		for (j = 0; j < model->H; j++) cout << getValue(model->Gamma, i, j) <<'\t';
		cout << "\n";
	}
	cout << "\n";
	
	cout<<"C : \n";
	for (i = 0; i < model->M; i++) {
		for (j = 0; j < model->H; j++) cout << getValue(model->C, i, j) <<'\t';
		cout << "\n";
	}
	cout << "\n";	
	
	cout<<"Sigma : \n";
	for (i = 0; i < model->M; i++) {
		for (j = 0; j < model->M; j++) cout << getValue(model->Sigma, i, j) <<'\t';
		cout << "\n";
	}
	cout << "\n";
		
	cout<<"u0 : \n";
	for (i = 0; i < model->H; i++) {
		cout << getValue(model->u0, i) <<'\t';
	}
	cout << "\n";
	
	cout<<"V0 : \n";
	for (i = 0; i < model->H; i++) {
		for (j = 0; j < model->H; j++) cout << getValue(model->V0, i, j) <<'\t';
		cout << "\n";
	}
	cout << "\n";

	cout<<"LL : \n";
	for (i = 0; i < MAX_ITER; i++) {
		cout << LL[i] <<'\t';
	}
	cout << "\n";


	cout << "\n\n";
	cout.close(); 
	
}


void test(char * fname, int numProcs) {
	
	KalmanData * data;
	
	KalmanModel * model;
	
	data = readData(fname);
	
	model = initModel(data->M, data->H);

	memset(LL, 0, sizeof(double) * MAX_ITER);
	
	learning(data, model, numProcs);
	

	
	outputModel(model);
	deleteModel(model);
	deleteData(data);
}


int main(int argc, char *argv[]) {

	
	int numProcs;
    double totalTime, parallelTime;
	
    /* Get thenumber of processors from the command line */
    if (argc < 3){
        printf("Usage: paralearn [filename] [numProcs]\n");
        exit(1);
    }
	
	
    sscanf(argv[2], "%d", &numProcs);
    if (numProcs < 1 || numProcs > MAXPROC){
        printf("Bad number of Processors (%d)\n", numProcs);
        exit(1);
    }
    
    /* Record start of initialization time. */
    gettimeofday(&startInitTime, NULL);
    
    /* Set the number of threads for the parallel region */
    omp_set_num_threads(numProcs);
    
    /* Record start computation time. */
	//gettimeofday(&startCompTime, NULL);
	
	/* begin computation */ 
	test(argv[1], numProcs);	
    
    /* Record final time. */        
    gettimeofday(&endTotalTime, NULL);
	
    
    /* Print out total and parallel computation times. */
    parallelTime = (endCompTime.tv_sec - startCompTime.tv_sec) * 1000.0
        + (endCompTime.tv_usec - startCompTime.tv_usec) / 1000.0;

    totalTime = (endTotalTime.tv_sec - startInitTime.tv_sec) * 1000.0
        + (endTotalTime.tv_usec - startInitTime.tv_usec) / 1000.0;


    printf("%d Processors:\n", numProcs);
    printf("   Parallel Time = %.3f millisecs\n", parallelTime);
    printf("      Total Time = %.3f millisecs\n", totalTime);
	
return 0;
}
