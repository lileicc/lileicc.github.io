/* This source code is (c) Copyright 2008 by Lei Li.
 * All rights preserved.
 *
 * Permission is granted to use it for non-profit purposes,
 * including research and teaching. For-profit use requires
 * the express consent of the author (leili@cs.cmu.edu).
 */

#ifndef MATRIX_H_
#define MATRIX_H_

typedef struct {
	int n; //length
	double* data;  
} Vector;

typedef struct {
	int n;//length
	int m;//width, # of columns
	double* data;
} Matrix;

Vector * newVector(int n);

Matrix * newMatrix(int n, int m);

void zeros(Vector * a);

void zeros(Matrix * A);

void eye(Matrix * A);

Vector * makeVector(double * data, int n);

Matrix * makeMatrix(double * data, int n, int m);

void deleteVector(Vector* vec);
void deleteMatrix(Matrix* mat);

double getValue(Matrix * mat, int i, int j);

double getValue(Vector * vec, int i);

double trace(Matrix * mat);

void copy(Matrix * A, Matrix * B);

void copy(Vector * A, Vector * B);

//sum of the abs of x
double sumAbs(Vector *x);

// B = A + x * y';
void addOuterProd(Matrix * A, Vector * x, Vector * y, Matrix* B);

// c = alpha * a;
void scale(Vector * a, double alpha, Vector * c);

// C = alpha * A
void scale(Matrix * A, double alpha, Matrix * C);


// C = only keep diagonal of value
void diag(double value, Matrix * C);


// C = diag(A)
void diag(Matrix * A, Matrix * C);


// c(i) = a(i) + b(i)
void add(Vector * a, Vector * b, Vector * c);

// c(i,j) = a(i,j) + b(i,j)
void add(Matrix * a, Matrix * b, Matrix * c);

// c(i) = a(i) - b(i)
void substract(Vector * a, Vector * b, Vector * c);

// c(i,j) = a(i,j) - b(i,j)
void substract(Matrix * a, Matrix * b, Matrix * c);

/* if (opA == 0)
 * 		y = A * x
 * elseif (opA == 1)
 * 		y = A' * x;
 * else
 * 		error!
 * end
 * 
 */ 
void multiply(Matrix * A, int opA, Vector * x, Vector * y);

/* if (opA == 0 && opB == 0)
 * 		C = A * B
 * elseif (opA == 1 && opB == 0)
 * 		C = A' * B;
 * elseif (opA == 0 && opB == 1)
 * 		C = A * B';
 * elseif (opA == 1 && opB == 1)
 * 		C = A' * B';
 * else
 * 		error!
 * end
 * 
 */
void multiply(Matrix * A, int opA, Matrix * B, int opB, Matrix * C);

/*
 * if opB == 0
 * to solve X * A = B, X = B * A^{-1}
 * elseif opB = 1
 * to solve X * A = B', X = B' * A^{-1}
 * where A is symmetrix
 */ 
void symSolveRinv(Matrix * A, Matrix * B, int opB, Matrix * X);


void outputVector(Vector * vec);

void outputMatrix(Matrix * mat);
#endif /*MATRIX_H_*/
